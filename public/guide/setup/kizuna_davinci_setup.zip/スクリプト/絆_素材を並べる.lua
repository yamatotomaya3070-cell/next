-- 絆_素材を並べる.lua
-- DaVinci Resolve の［ワークスペース］→［スクリプト］から実行する。無料版で動く（内部スクリプト）。
--
-- やること（単純作業だけを自動化。字幕・強調テロップ・音量・書き出しは利用者が行う）
--   1. プロジェクトを 1280x720 / 24fps にする（まだタイムラインが無いときだけ）
--   2. タイムライン「本編」を作り、トラック名を付ける（V1映像 V2立ち絵 V3字幕 V4強調テロップ / A1セリフ A2BGM）
--   3. メディアプールの素材を、ファイル名の番号順に並べる
--        オープニング.mp4 → S01_*.mp4 と S01_01_*.wav… → … → エンディング.mp4
--        セリフの間は完成見本と同じ（場面の頭0.4秒・セリフ間0.28秒）
--   4. BGM.wav を本編の長さぶん A2 に並べる（音量は利用者が調整）
--   5. 書き出しプリセット「絆_YouTube_720p」を読み込む（まだ無ければ）
--   6. 終わったら、タイムラインの先頭に緑のマーカーを置く（失敗は赤）
--
-- 前提: 利用者が「素材」フォルダをメディアプールに入れてあること。

local FPS = 24
local HEAD, GAP, TAIL = 0.4, 0.28, 0.5
local TIMELINE_NAME = "本編"
local PRESET_NAME = "絆_YouTube_720p"

local resolveApp = resolve or (bmd and bmd.scriptapp and bmd.scriptapp("Resolve"))
local fusionApp = fu or fusion or (resolveApp and resolveApp:Fusion())

-- ---------- メッセージ表示 ----------
-- 無料版では画面に窓を出す機能(UIManager)が使えない。
-- 並べ終わったとき：タイムラインの先頭に緑のマーカー（失敗は赤）を置く。マーカーをダブルクリックすると文が読める。
-- タイムラインを作る前に止まったとき：メディアプールに「【お知らせ】…」というフォルダを作って知らせる。
local noticeTimeline = nil
local function notify(title, message, color)
  print("[" .. title .. "] " .. message)
  local shown = false
  if noticeTimeline then
    shown = pcall(function()
      noticeTimeline:DeleteMarkerAtFrame(0)
      noticeTimeline:AddMarker(0, color or "Green", title, message, 1)
    end)
  end
  if not shown then
    pcall(function()
      local p = resolveApp:GetProjectManager():GetCurrentProject()
      local mp = p:GetMediaPool()
      local first = message:match("^[^\n]+") or message
      mp:AddSubFolder(mp:GetRootFolder(), "【お知らせ】" .. first)
    end)
  end
end

-- ---------- 小さな道具 ----------
local function isObject(v) return type(v) ~= "number" and type(v) ~= "string" and v ~= nil end

local function listOf(t)
  local out = {}
  for _, v in pairs(t or {}) do if isObject(v) then out[#out + 1] = v end end
  return out
end

local function clipFrames(clip)
  local f = tonumber(clip:GetClipProperty("Frames"))
  if f and f > 0 then return f end
  local d = tostring(clip:GetClipProperty("Duration") or "")
  local h, m, s, fr = d:match("(%d+):(%d+):(%d+)[:;](%d+)")
  if not h then return nil end
  return ((tonumber(h) * 60 + tonumber(m)) * 60 + tonumber(s)) * FPS + tonumber(fr)
end

local function round(x) return math.floor(x + 0.5) end

-- ---------- 本体 ----------
local function run()
  if not resolveApp then
    print("DaVinci Resolve に接続できませんでした。［ワークスペース］→［スクリプト］から実行してください。")
    return
  end
  local pm = resolveApp:GetProjectManager()
  local proj = pm:GetCurrentProject()
  if not proj then
    notify("絆 素材を並べる", "プロジェクトが開かれていません。\nプロジェクトを開いてから、もう一度実行してください。")
    return
  end
  local mp = proj:GetMediaPool()

  -- 1) メディアプールの素材を名前で探す
  local voices, videos = {}, {}
  local opening, ending, bgm
  local function walk(folder)
    for _, clip in ipairs(listOf(folder:GetClipList())) do
      local name = clip:GetName()
      local sn, ln = name:match("^S(%d+)_(%d+)_.+%.wav$")
      local vn = name:match("^S(%d+)_.+%.mp4$")
      if sn then
        local key = tonumber(sn)
        voices[key] = voices[key] or {}
        table.insert(voices[key], { no = tonumber(ln), clip = clip })
      elseif vn then
        videos[tonumber(vn)] = clip
      elseif name == "オープニング.mp4" then
        opening = clip
      elseif name == "エンディング.mp4" then
        ending = clip
      elseif name == "BGM.wav" then
        bgm = clip
      end
    end
    for _, sub in ipairs(listOf(folder:GetSubFolderList())) do walk(sub) end
  end
  walk(mp:GetRootFolder())

  local sceneNos = {}
  for no in pairs(voices) do sceneNos[#sceneNos + 1] = no end
  table.sort(sceneNos)
  if #sceneNos == 0 then
    notify("絆 素材を並べる", "セリフの音声（S01_01_〇〇.wav など）が見つかりません。\n先に「素材」フォルダを、左上のメディアプールへドラッグして入れてください。")
    return
  end

  -- 2) すでに並べてあるなら二重に置かない
  for i = 1, proj:GetTimelineCount() do
    local t = proj:GetTimelineByIndex(i)
    if t:GetName() == TIMELINE_NAME then
      local used = #listOf(t:GetItemListInTrack("audio", 1)) + #listOf(t:GetItemListInTrack("video", 1))
      if used > 0 then
        notify("絆 素材を並べる", "タイムライン「" .. TIMELINE_NAME .. "」には、もう素材が並んでいます。\nやり直すときは、タイムラインを消してから実行してください。")
        return
      end
    end
  end

  -- 3) プロジェクト設定（タイムラインがまだ無いときだけ変更できる）
  if proj:GetTimelineCount() == 0 then
    proj:SetSetting("timelineResolutionWidth", "1280")
    proj:SetSetting("timelineResolutionHeight", "720")
    proj:SetSetting("timelineFrameRate", "24")
  end
  local w, h = proj:GetSetting("timelineResolutionWidth"), proj:GetSetting("timelineResolutionHeight")
  local fps = tonumber(proj:GetSetting("timelineFrameRate"))
  if w ~= "1280" or h ~= "720" or not fps or math.abs(fps - FPS) > 0.01 then
    notify("絆 素材を並べる", "このプロジェクトは 1280×720・24fps になっていません（今は " .. tostring(w) .. "×" .. tostring(h) .. "・" .. tostring(fps) .. "fps）。\n新しいプロジェクトを作って、素材を入れてから実行してください。")
    return
  end

  -- 4) タイムラインとトラック
  local tl = nil
  for i = 1, proj:GetTimelineCount() do
    local t = proj:GetTimelineByIndex(i)
    if t:GetName() == TIMELINE_NAME then tl = t end
  end
  tl = tl or mp:CreateEmptyTimeline(TIMELINE_NAME)
  if not tl then
    notify("絆 素材を並べる", "タイムラインを作れませんでした。DaVinci Resolve を開き直して、もう一度実行してください。")
    return
  end
  proj:SetCurrentTimeline(tl)
  noticeTimeline = tl
  while tl:GetTrackCount("video") < 4 do tl:AddTrack("video") end
  while tl:GetTrackCount("audio") < 2 do tl:AddTrack("audio", "stereo") end
  local vNames = { "映像", "立ち絵", "字幕", "強調テロップ" }
  local aNames = { "セリフ", "BGM" }
  for i, n in ipairs(vNames) do tl:SetTrackName("video", i, n) end
  for i, n in ipairs(aNames) do tl:SetTrackName("audio", i, n) end

  -- 5) 並べる
  local failures = {}
  local function place(clip, track, mediaType, recordFrame, length, label)
    local info = { mediaPoolItem = clip, startFrame = 0, endFrame = length - 1,
      trackIndex = track, recordFrame = recordFrame, mediaType = mediaType }
    local res = mp:AppendToTimeline({ info })
    if not res or #listOf(res) == 0 then failures[#failures + 1] = label end
  end

  local start = tl:GetStartFrame()
  local pos = start
  local counts = { video = 0, voice = 0, bgm = 0 }

  if opening then
    local n = clipFrames(opening)
    place(opening, 1, 1, pos, n, "オープニング(映像)")
    place(opening, 1, 2, pos, n, "オープニング(音)")
    pos = pos + n
  end
  local bodyStart = pos

  for _, no in ipairs(sceneNos) do
    local lines = voices[no]
    table.sort(lines, function(a, b) return a.no < b.no end)
    local sceneStart = pos
    local t = HEAD
    for _, ln in ipairs(lines) do
      local n = clipFrames(ln.clip)
      if n then
        place(ln.clip, 1, 2, sceneStart + round(t * FPS), n, ln.clip:GetName())
        counts.voice = counts.voice + 1
        t = t + n / FPS + GAP
      else
        failures[#failures + 1] = ln.clip:GetName()
      end
    end
    local sceneLen = round((t - GAP + TAIL) * FPS)
    local video = videos[no]
    if video then
      local vn = clipFrames(video) or sceneLen
      place(video, 1, 1, sceneStart, vn, video:GetName())
      counts.video = counts.video + 1
      if vn > sceneLen then sceneLen = vn end
    else
      failures[#failures + 1] = string.format("S%02d の映像", no)
    end
    pos = sceneStart + sceneLen
  end
  local bodyEnd = pos

  if bgm then
    local bn = clipFrames(bgm)
    local b = bodyStart
    while bn and b < bodyEnd do
      local len = math.min(bn, bodyEnd - b)
      place(bgm, 2, 2, b, len, "BGM")
      counts.bgm = counts.bgm + 1
      b = b + len
    end
  else
    failures[#failures + 1] = "BGM.wav"
  end

  if ending then
    local n = clipFrames(ending)
    place(ending, 1, 1, pos, n, "エンディング(映像)")
    place(ending, 1, 2, pos, n, "エンディング(音)")
    pos = pos + n
  end

  -- 6) 書き出しプリセット
  pcall(function()
    local have = false
    for _, p in pairs(proj:GetRenderPresetList() or {}) do if p == PRESET_NAME then have = true end end
    if not have then
      -- セットアップ用 bat が、スクリプトと同じ Scripts/Utility にプリセットを置いている
      resolveApp:ImportRenderPreset(fusionApp:MapPath("Scripts:Utility/" .. PRESET_NAME .. ".xml"))
    end
  end)

  pm:SaveProject()
  pcall(function() tl:SetCurrentTimecode(tl:GetStartTimecode()) end)

  local seconds = (pos - start) / FPS
  local msg = string.format("並べ終わりました。\n場面の映像 %d本・セリフ %d本・BGM %d本%s%s\n動画の長さ 約%d分%02d秒\n次は、手順書の「字幕を入れる」に進んでください。",
    counts.video, counts.voice, counts.bgm,
    opening and "・オープニング" or "", ending and "・エンディング" or "",
    math.floor(seconds / 60), math.floor(seconds % 60))
  local color = "Green"
  if #failures > 0 then
    msg = msg .. "\n※ 置けなかったもの：" .. table.concat(failures, "、") .. "\n支援員さんに声をかけてください。"
    color = "Red"
  end
  notify("絆 素材を並べる", msg, color)
end

local ok, err = pcall(run)
if not ok then
  notify("絆 素材を並べる", "とちゅうで止まりました。支援員さんに声をかけてください。\n" .. tostring(err), "Red")
end
