@echo off
chcp 65001 >nul
setlocal
rem ===== 職員用：1台のパソコンで最初に1回だけ実行します =====
rem 字幕とテロップの型、「素材を並べる」スクリプト、書き出し設定を DaVinci Resolve に入れます。
set "BASE=%APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion"
set "TITLES=%BASE%\Templates\Edit\Titles\絆テンプレート"
set "SCRIPTS=%BASE%\Scripts\Utility"
if not exist "%BASE%" (
  echo DaVinci Resolve が見つかりません。先に DaVinci Resolve をインストールして、1回起動してください。
  goto :end
)
if not exist "%TITLES%" mkdir "%TITLES%"
if not exist "%SCRIPTS%" mkdir "%SCRIPTS%"
copy /Y "%~dp0字幕とテロップ\*.setting" "%TITLES%\" >nul || goto :fail
copy /Y "%~dp0スクリプト\*.lua" "%SCRIPTS%\" >nul || goto :fail
copy /Y "%~dp0スクリプト\*.xml" "%SCRIPTS%\" >nul || goto :fail
echo.
echo セットアップが終わりました。
echo DaVinci Resolve を開いている場合は、一度とじてから開きなおしてください。
goto :end
:fail
echo.
echo コピーできませんでした。フォルダの場所を確かめてください。
:end
echo.
pause
