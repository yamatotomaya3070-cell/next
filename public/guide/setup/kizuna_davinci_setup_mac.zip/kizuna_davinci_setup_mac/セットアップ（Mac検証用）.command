#!/bin/bash
# 絆 DaVinci Resolve セットアップ（Mac 検証用）
# 字幕とテロップの型、「素材を並べる」スクリプト、書き出し設定を DaVinci Resolve に入れます。
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1
# ダウンロードしたファイルに付く「隔離」の印を外す（失敗しても続ける）
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null

finish() { echo; read -r -p "Enter キーを押すと、この画面をとじられます。" _; exit "$1"; }

echo "macOS $(sw_vers -productVersion 2>/dev/null)  /  $(uname -m)"

# DaVinci Resolve の Fusion フォルダを探す
#  ・公式サイト版:   ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion
#  ・App Store 版:  ~/Library/Containers/… の中（場所が版によって違うので探す）
BASES=()
STD="$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion"
[ -d "$STD" ] && BASES+=("$STD")
if [ -d "$HOME/Library/Containers" ]; then
  while IFS= read -r d; do BASES+=("$d"); done < <(
    find "$HOME/Library/Containers" -maxdepth 9 -type d -path "*DaVinci*Resolve*/Fusion" 2>/dev/null
  )
fi

if [ ${#BASES[@]} -eq 0 ]; then
  echo "DaVinci Resolve が見つかりません。"
  echo "先に DaVinci Resolve をインストールして、1回起動して、とじてから、もう一度実行してください。"
  echo "（探した場所: $STD と ~/Library/Containers の中）"
  finish 1
fi

ok=0
for BASE in "${BASES[@]}"; do
  TITLES="$BASE/Templates/Edit/Titles/絆テンプレート"
  SCRIPTS="$BASE/Scripts/Utility"
  echo
  echo "入れる場所: $BASE"
  if mkdir -p "$TITLES" "$SCRIPTS" \
    && cp -f "$HERE"/字幕とテロップ/*.setting "$TITLES/" \
    && cp -f "$HERE"/スクリプト/*.lua "$HERE"/スクリプト/*.xml "$SCRIPTS/"; then
    echo "  → 入れました"
    ok=1
  else
    echo "  → コピーできませんでした"
  fi
done

echo
if [ $ok -eq 1 ]; then
  echo "セットアップが終わりました。"
  echo "DaVinci Resolve を開いている場合は、一度とじてから開きなおしてください。"
  finish 0
fi
echo "コピーできませんでした。ZIP をまるごと展開したフォルダから実行しているか確かめてください。"
echo "この画面の文字を、そのまま担当者に送ってください。"
finish 1
